format compact;
close all;
clear;
clc;

xn = input('Enter input vector: ');

Xk = dft_fun(xn);
disp(Xk)