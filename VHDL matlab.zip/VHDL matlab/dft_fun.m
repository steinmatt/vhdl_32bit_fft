function Xk = dft_fun(xn)
N = length(xn);

% subtractions output bottom 16
%x_m(n) is the matrix for all the subtractions
%x_p(n) is the matrix for all the additions
for n = 1:N/2
    x_m(n) = xn(n) - xn((N/2)+n);
    x_p(n) = xn(n) + xn((N/2)+n);
end

% Twiddle Factor
for n = N/2:N
    Wn(n) = exp(-j*2*pi*n/N);
end
Wn = Wn((end/2)+1:end);              % Truncate W

% multiply subtractions by W
x_m = x_m .* Wn;

% concatenate additions with subtractions
Xk = [x_p x_m];



    
