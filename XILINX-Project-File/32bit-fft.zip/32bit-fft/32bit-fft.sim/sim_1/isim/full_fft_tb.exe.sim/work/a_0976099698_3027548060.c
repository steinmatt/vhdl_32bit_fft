/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/mstein12/Desktop/vhdl_32bit_fft/Twiddle.vhd";



static void work_a_0976099698_3027548060_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t7;
    char *t9;
    char *t11;
    char *t13;
    char *t15;
    char *t17;
    char *t19;
    char *t21;
    char *t23;
    char *t25;
    char *t27;
    char *t29;
    char *t31;
    char *t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;

LAB0:    xsi_set_current_line(81, ng0);

LAB3:    t1 = xsi_get_transient_memory(256U);
    memset(t1, 0, 256U);
    t2 = t1;
    t3 = (t0 + 4764);
    memcpy(t2, t3, 16U);
    t2 = (t2 + 16U);
    t5 = (t0 + 4780);
    memcpy(t2, t5, 16U);
    t2 = (t2 + 16U);
    t7 = (t0 + 4796);
    memcpy(t2, t7, 16U);
    t2 = (t2 + 16U);
    t9 = (t0 + 4812);
    memcpy(t2, t9, 16U);
    t2 = (t2 + 16U);
    t11 = (t0 + 4828);
    memcpy(t2, t11, 16U);
    t2 = (t2 + 16U);
    t13 = (t0 + 4844);
    memcpy(t2, t13, 16U);
    t2 = (t2 + 16U);
    t15 = (t0 + 4860);
    memcpy(t2, t15, 16U);
    t2 = (t2 + 16U);
    t17 = (t0 + 4876);
    memcpy(t2, t17, 16U);
    t2 = (t2 + 16U);
    t19 = (t0 + 4892);
    memcpy(t2, t19, 16U);
    t2 = (t2 + 16U);
    t21 = (t0 + 4908);
    memcpy(t2, t21, 16U);
    t2 = (t2 + 16U);
    t23 = (t0 + 4924);
    memcpy(t2, t23, 16U);
    t2 = (t2 + 16U);
    t25 = (t0 + 4940);
    memcpy(t2, t25, 16U);
    t2 = (t2 + 16U);
    t27 = (t0 + 4956);
    memcpy(t2, t27, 16U);
    t2 = (t2 + 16U);
    t29 = (t0 + 4972);
    memcpy(t2, t29, 16U);
    t2 = (t2 + 16U);
    t31 = (t0 + 4988);
    memcpy(t2, t31, 16U);
    t2 = (t2 + 16U);
    t33 = (t0 + 5004);
    memcpy(t2, t33, 16U);
    t35 = (t0 + 2984);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t1, 256U);
    xsi_driver_first_trans_fast_port(t35);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0976099698_3027548060_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t7;
    char *t9;
    char *t11;
    char *t13;
    char *t15;
    char *t17;
    char *t19;
    char *t21;
    char *t23;
    char *t25;
    char *t27;
    char *t29;
    char *t31;
    char *t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;

LAB0:    xsi_set_current_line(82, ng0);

LAB3:    t1 = xsi_get_transient_memory(256U);
    memset(t1, 0, 256U);
    t2 = t1;
    t3 = (t0 + 5020);
    memcpy(t2, t3, 16U);
    t2 = (t2 + 16U);
    t5 = (t0 + 5036);
    memcpy(t2, t5, 16U);
    t2 = (t2 + 16U);
    t7 = (t0 + 5052);
    memcpy(t2, t7, 16U);
    t2 = (t2 + 16U);
    t9 = (t0 + 5068);
    memcpy(t2, t9, 16U);
    t2 = (t2 + 16U);
    t11 = (t0 + 5084);
    memcpy(t2, t11, 16U);
    t2 = (t2 + 16U);
    t13 = (t0 + 5100);
    memcpy(t2, t13, 16U);
    t2 = (t2 + 16U);
    t15 = (t0 + 5116);
    memcpy(t2, t15, 16U);
    t2 = (t2 + 16U);
    t17 = (t0 + 5132);
    memcpy(t2, t17, 16U);
    t2 = (t2 + 16U);
    t19 = (t0 + 5148);
    memcpy(t2, t19, 16U);
    t2 = (t2 + 16U);
    t21 = (t0 + 5164);
    memcpy(t2, t21, 16U);
    t2 = (t2 + 16U);
    t23 = (t0 + 5180);
    memcpy(t2, t23, 16U);
    t2 = (t2 + 16U);
    t25 = (t0 + 5196);
    memcpy(t2, t25, 16U);
    t2 = (t2 + 16U);
    t27 = (t0 + 5212);
    memcpy(t2, t27, 16U);
    t2 = (t2 + 16U);
    t29 = (t0 + 5228);
    memcpy(t2, t29, 16U);
    t2 = (t2 + 16U);
    t31 = (t0 + 5244);
    memcpy(t2, t31, 16U);
    t2 = (t2 + 16U);
    t33 = (t0 + 5260);
    memcpy(t2, t33, 16U);
    t35 = (t0 + 3048);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t1, 256U);
    xsi_driver_first_trans_fast_port(t35);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0976099698_3027548060_init()
{
	static char *pe[] = {(void *)work_a_0976099698_3027548060_p_0,(void *)work_a_0976099698_3027548060_p_1};
	xsi_register_didat("work_a_0976099698_3027548060", "isim/full_fft_tb.exe.sim/work/a_0976099698_3027548060.didat");
	xsi_register_executes(pe);
}
