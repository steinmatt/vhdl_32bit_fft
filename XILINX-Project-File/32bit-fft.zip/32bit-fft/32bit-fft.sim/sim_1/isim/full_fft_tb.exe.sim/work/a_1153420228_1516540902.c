/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/mstein12/Desktop/vhdl_32bit_fft/adder.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_3273497107_1035706684(char *, char *, char *, char *, char *, char *);


static void work_a_1153420228_1516540902_p_0(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB9;

LAB10:
LAB3:    t1 = (t0 + 3472);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 1032U);
    t6 = *((char **)t1);
    t1 = (t0 + 5496U);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t7 = (t0 + 5512U);
    t9 = ieee_p_1242562249_sub_3273497107_1035706684(IEEE_P_1242562249, t5, t6, t1, t8, t7);
    t10 = (t5 + 12U);
    t11 = *((unsigned int *)t10);
    t12 = (1U * t11);
    t13 = (16U != t12);
    if (t13 == 1)
        goto LAB5;

LAB6:    t14 = (t0 + 3552);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t9, 16U);
    xsi_driver_first_trans_fast_port(t14);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 5528U);
    t6 = (t0 + 1512U);
    t7 = *((char **)t6);
    t6 = (t0 + 5544U);
    t8 = ieee_p_1242562249_sub_3273497107_1035706684(IEEE_P_1242562249, t5, t2, t1, t7, t6);
    t9 = (t5 + 12U);
    t11 = *((unsigned int *)t9);
    t12 = (1U * t11);
    t3 = (16U != t12);
    if (t3 == 1)
        goto LAB7;

LAB8:    t10 = (t0 + 3616);
    t14 = (t10 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t8, 16U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB3;

LAB5:    xsi_size_not_matching(16U, t12, 0);
    goto LAB6;

LAB7:    xsi_size_not_matching(16U, t12, 0);
    goto LAB8;

LAB9:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 5665);
    t7 = (t0 + 3552);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t14 = *((char **)t10);
    memcpy(t14, t1, 16U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 5681);
    t6 = (t0 + 3616);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 16U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

}


extern void work_a_1153420228_1516540902_init()
{
	static char *pe[] = {(void *)work_a_1153420228_1516540902_p_0};
	xsi_register_didat("work_a_1153420228_1516540902", "isim/full_fft_tb.exe.sim/work/a_1153420228_1516540902.didat");
	xsi_register_executes(pe);
}
